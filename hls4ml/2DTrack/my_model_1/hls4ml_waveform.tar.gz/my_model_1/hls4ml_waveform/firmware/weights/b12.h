//Numpy array shape [3]
//Min -0.026163889095
//Max 0.023791043088
//Number of zeros 0

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
model_default_t b12[3];
#else
model_default_t b12[3] = {0.0237910431, -0.0261638891, -0.0215803906};
#endif

#endif
